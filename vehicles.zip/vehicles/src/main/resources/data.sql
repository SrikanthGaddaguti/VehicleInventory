insert into Vehicle
values(1,'Toyota', 'Sedan','8','blue','2015','FourCylinder', 'YES','A2Z134','Iron');

insert into Vehicle
values(2,'Benz', 'Hatch Back','4','Red','2018','SixCylinder', 'YES','GAR358','Steel');

insert into Vehicle
values(3,'Hundai', 'Coupe','4','Black','2017','SixCylinder', 'YES','CXF117','Aluminium');

insert into Vehicle
values(4,'Honda', 'Truck','4','Silver','2018','FourCylinder', 'YES','AMF121','Aluminium');

insert into Vehicle
values(5,'Audi', 'Sedan','4','Gray','2019','EightCylinder', 'YES','AXF181','Iron');